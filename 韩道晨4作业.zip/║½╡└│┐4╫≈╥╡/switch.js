/**
 * Created by lenovo on 2017/6/29.
 */
//一.创建一个服务器
//要求： 1.用到switch语句来处理请求
//2.最少三个页面(不算报错页面)，这三个页面间可以相互跳转
//3.某一个页面上必须有图片，外部的css和js代码
//4.如果输入的请求没有定义，发送一个报错页面
var http=require("http");
var fs=require("fs");
http.createServer(function(req,res){
    console.log(req.url);
    var url=req.url;
    switch(url){
        case "/":  fs.readFile("dc/a.html","utf-8",function(err,data){
            if(err){
                console.log("读取失败");
                console.log(err)
            }else{

                res.writeHead(200,{"content-type":"text/html;charset=utf8"})
                res.end(data);
            }
        })
            break;
        case "/css.css":   fs.readFile("dc/css.css","utf-8",function(err,data){
            if(err){
                console.log("读取失败");
                console.log(err)
            }else{

                res.writeHead(200,{"content-type":"text/css;charset=utf8"})
                res.end(data);
            }
        })
            break;
        case "/js.js":   fs.readFile("dc/js.js","utf-8",function(err,data){
            if(err){
                console.log("读取失败");
                console.log(err)
            }else{

                res.writeHead(200,{"content-type":"text/javascript;charset=utf8"})
                res.end(data);
            }
        })

            break;
        case "/aa.jpg":    fs.readFile("dc/aa.jpg",function(err,data){
            if(err){
                console.log("读取失败");
                console.log(err)
            }else{

                res.writeHead(200,{"content-type":"image/jpeg;charset=utf8"})
                res.end(data);
            }
        })
            break;

        case "/b.html":    fs.readFile("dc/b.html",function(err,data){
            if(err){
                console.log("读取失败");
                console.log(err)
            }else{

                res.writeHead(200,{"content-type":"text/html;charset=utf8"})
                res.end(data);
            }
        })
            break;
        case "/c.html":    fs.readFile("dc/c.html",function(err,data){
            if(err){
                console.log("读取失败");
                console.log(err)
            }else{

                res.writeHead(200,{"content-type":"text/html;charset=utf8"})
                res.end(data);
            }
        })
        //    break;
        //default:
        //    console.log("404 not found")
    }

}).listen(3000)